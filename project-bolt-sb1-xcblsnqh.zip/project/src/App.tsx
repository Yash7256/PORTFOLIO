import React, { useState, useEffect, useRef } from 'react';
import {
  Brain,
  Terminal,
  Code,
  Cpu,
  Github,
  Mail,
  Linkedin,
  Moon,
  Sun,
  ChevronDown,
  X,
  Maximize,
  Minimize,
} from 'lucide-react';
import BootSequence from './components/BootSequence';
import Navbar from './components/Navbar';
import HolographicCard from './components/HolographicCard';
import ChatBot from './components/ChatBot';
import { useMousePosition } from './hooks/useMousePosition';
import { useDeviceOrientation } from './hooks/useDeviceOrientation';
import { useLocalStorage } from './hooks/useLocalStorage';

function App() {
  const [loading, setLoading] = useState(true);
  const [darkMode, setDarkMode] = useState(false);
  const [matrixMode, setMatrixMode] = useState(false);
  const [showChat, setShowChat] = useState(false);
  const [terminalOpen, setTerminalOpen] = useState(false);
  const [visitCount, setVisitCount] = useLocalStorage('visitCount', 0);
  const [lastVisit, setLastVisit] = useLocalStorage('lastVisit', null);
  const [terminalInput, setTerminalInput] = useState('');
  const [terminalOutput, setTerminalOutput] = useState<string[]>([
    'Neural Terminal v3.0.1',
    'Type "help" for available commands',
    '> ',
  ]);

  const mousePosition = useMousePosition();
  const deviceOrientation = useDeviceOrientation();
  const appRef = useRef<HTMLDivElement>(null);
  const terminalRef = useRef<HTMLDivElement>(null);
  const terminalInputRef = useRef<HTMLInputElement>(null);

  // Projects data
  const softwareProjects = [
    {
      id: 1,
      title: 'Facial Attendance System',
      description: 'A Python Based Facial Attendance System',
      tags: ['Python', 'SQL'],
      image: '',
    },
    {
      id: 2,
      title: 'AI Assistant',
      description: 'Personalised Assistant',
      tags: ['Python'],
      image:
        'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
    },
  ];

  const hardwareProjects = [
    {
      id: 4,
      title: 'Human/Object Following Bot ',
      description: 'Arduino based bot which follows object',
      tags: ['IOT'],
      image: '',
    },
    {
      id: 5,
      title: 'Neural Interface Module',
      description:
        'Brain-computer interface prototype for direct neural communication.',
      tags: ['BCI', 'Neural', 'Embedded'],
      image:
        'https://images.unsplash.com/photo-1581093458791-9d15482442f6?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
    },
    {
      id: 6,
      title: 'Holographic Display Unit',
      description:
        'Volumetric display technology for true 3D holographic projections.',
      tags: ['Optics', 'Electronics', '3D'],
      image:
        'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
    },
  ];

  useEffect(() => {
    // Increment visit count and store last visit time
    setVisitCount((prev) => prev + 1);
    const now = new Date().toISOString();
    setLastVisit(now);

    // Simulate loading sequence
    const timer = setTimeout(() => {
      setLoading(false);
    }, 5000);

    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    // Handle key press for dark matter mode
    const handleKeyDown = (e: KeyboardEvent) => {
      // 'D' key for dark matter mode
      if (e.key === 'd' && e.altKey) {
        setDarkMode((prev) => !prev);
      }

      // 'T' key for terminal
      if (e.key === 't' && e.altKey) {
        setTerminalOpen((prev) => !prev);
        setTimeout(() => {
          terminalInputRef.current?.focus();
        }, 100);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Terminal command handler
  const handleTerminalSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const command = terminalInput.trim().toLowerCase();
    let response = '';

    switch (command) {
      case 'help':
        response = `
Available commands:
- help: Show this help message
- clear: Clear terminal
- matrix: Toggle Matrix digital rain effect
- darkmode: Toggle dark mode
- status: Show system status
- about: Display about information
- exit: Close terminal
        `;
        break;
      case 'clear':
        setTerminalOutput(['Neural Terminal v3.0.1', '> ']);
        setTerminalInput('');
        return;
      case 'matrix':
        setMatrixMode((prev) => !prev);
        response = `Matrix mode ${matrixMode ? 'deactivated' : 'activated'}`;
        break;
      case 'darkmode':
        setDarkMode((prev) => !prev);
        response = `Dark matter mode ${darkMode ? 'deactivated' : 'activated'}`;
        break;
      case 'status':
        const time = new Date().toLocaleTimeString();
        response = `
System Status:
- Time: ${time}
- Visit count: ${visitCount}
- Dark mode: ${darkMode ? 'Active' : 'Inactive'}
- Matrix mode: ${matrixMode ? 'Active' : 'Inactive'}
- Neural core: Online
- Quantum processor: Stable
        `;
        break;
      case 'about':
        response = `
Neural Portfolio System v2.0
Created by Aman Raj
Contact: amanrajengg@gmail.com
        `;
        break;
      case 'exit':
        setTerminalOpen(false);
        break;
      case '':
        response = '';
        break;
      default:
        response = `Command not recognized: ${command}`;
    }

    setTerminalOutput((prev) => [...prev, `> ${command}`, response, '> ']);
    setTerminalInput('');
  };

  // Calculate parallax effect based on mouse position or device orientation
  const getParallaxStyle = () => {
    const xOffset = (mousePosition.x / window.innerWidth) * 20 - 10;
    const yOffset = (mousePosition.y / window.innerHeight) * 20 - 10;

    // Use device orientation on mobile if available
    const tiltX = deviceOrientation.beta
      ? (deviceOrientation.beta / 90) * 10
      : 0;
    const tiltY = deviceOrientation.gamma
      ? (deviceOrientation.gamma / 90) * 10
      : 0;

    return {
      transform: `perspective(1000px) rotateX(${yOffset + tiltX}px) rotateY(${
        xOffset + tiltY
      }px)`,
      transition: 'transform 0.1s ease-out',
    };
  };

  // Handle exit animation
  const handleBeforeUnload = () => {
    // This would ideally trigger an exit animation, but for now we'll just log
    console.log('Initiating shutdown sequence');
  };

  useEffect(() => {
    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, []);

  // Get time-based greeting
  const getTimeBasedGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 5) return 'Working late in the quantum realm?';
    if (hour < 12) return 'Good morning, explorer';
    if (hour < 18) return 'Afternoon quantum fluctuations detected';
    return 'Evening neural patterns activated';
  };

  // Get visit-based greeting
  const getVisitBasedGreeting = () => {
    if (visitCount === 1) return 'First contact established. Welcome.';
    if (visitCount < 5) return `Welcome back. Visit #${visitCount} recorded.`;
    return `Frequent visitor detected. Neural pathways strengthening. Visit #${visitCount}.`;
  };

  if (loading) {
    return <BootSequence onComplete={() => setLoading(false)} />;
  }

  return (
    <div
      ref={appRef}
      className={`min-h-screen transition-all duration-500 ${
        darkMode ? 'bg-black text-cyan-400' : 'bg-gray-900 text-cyan-300'
      }`}
    >
      {/* Matrix digital rain effect */}
      {matrixMode && (
        <div className="fixed inset-0 pointer-events-none z-10 opacity-30">
          <div className="matrix-rain"></div>
        </div>
      )}

      {/* Nebula background with parallax */}
      <div
        className="fixed inset-0 z-0 opacity-30 pointer-events-none"
        style={getParallaxStyle()}
      >
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-purple-900 via-black to-black"></div>
        <div className="nebula-effect"></div>
        <div className="neural-network-animation"></div>
      </div>

      {/* Main content */}
      <div className="relative z-20">
        <Navbar
          darkMode={darkMode}
          toggleDarkMode={() => setDarkMode((prev) => !prev)}
        />

        {/* Hero section with holographic effect */}
        <section className="relative min-h-screen flex flex-col items-center justify-center px-4 overflow-hidden">
          <div className="glitch-container mb-6">
            <h1
              className="text-5xl md:text-7xl font-bold glitch-text"
              data-text="AMAN RAJ"
            >
              AMAN RAJ
            </h1>
          </div>

          <div className="holographic-text mb-8 text-center">
            <p className="text-xl md:text-2xl font-light tracking-wider">
              QUANTUM DEVELOPER • AI ENGINEER • NEURAL ARCHITECT
            </p>
          </div>

          <div className="time-based-greeting text-center mb-12">
            <p className="text-lg md:text-xl font-light opacity-80">
              {getTimeBasedGreeting()}
            </p>
            <p className="text-sm md:text-base font-light opacity-60 mt-2">
              {getVisitBasedGreeting()}
            </p>
          </div>

          <div className="scroll-indicator animate-bounce">
            <ChevronDown size={32} />
          </div>
        </section>

        {/* About section */}
        <section
          id="about"
          className="min-h-screen flex flex-col items-center justify-center px-4 py-20"
        >
          <div className="max-w-4xl w-full">
            <div className="glitch-container mb-12">
              <h2
                className="text-4xl md:text-5xl font-bold glitch-text"
                data-text="NEURAL IDENTITY"
              >
                NEURAL IDENTITY
              </h2>
            </div>

            <div className="holographic-card p-8 rounded-lg backdrop-blur-md bg-opacity-10 bg-blue-900 border border-cyan-500/30">
              <div className="flex flex-col md:flex-row gap-8">
                <div className="md:w-1/3">
                  <div className="holographic-image-container rounded-lg overflow-hidden">
                    <img
                      src="https://images.unsplash.com/photo-1511367461989-f85a21fda167?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60"
                      alt="Neural Profile"
                      className="w-full h-auto"
                    />
                  </div>
                </div>

                <div className="md:w-2/3">
                  <p className="text-lg mb-4 leading-relaxed">
                    A passionate AI & Robotics Engineer with a deep interest in
                    Networking and IoT. Skilled in developing intelligent
                    systems, automation, and cutting-edge robotics solutions,
                    integrating AI-driven decision-making with real-world
                    applications. Enthusiastic about the intersection of machine
                    learning, embedded systems, and connected devices,
                    constantly exploring how IoT and networking can enhance the
                    capabilities of autonomous systems.
                  </p>

                  <p className="text-lg mb-6 leading-relaxed">
                    Proficient in Python, C, and embedded programming, with
                    experience in computer vision, deep learning, and sensor
                    fusion for robotics applications. Keen on building smart,
                    connected environments through wireless protocols, cloud
                    integration, and real-time data processing. Always seeking
                    innovative ways to bridge AI, robotics, and IoT for the
                    future of automation and smart technology.
                  </p>

                  <div className="skills-grid grid grid-cols-2 md:grid-cols-3 gap-4">
                    <div className="skill-item p-3 rounded-lg bg-cyan-900/20 border border-cyan-500/20">
                      <div className="flex items-center gap-2">
                        <Brain size={18} />
                        <span>Neural Networks</span>
                      </div>
                    </div>
                    <div className="skill-item p-3 rounded-lg bg-cyan-900/20 border border-cyan-500/20">
                      <div className="flex items-center gap-2">
                        <Code size={18} />
                        <span>ML</span>
                      </div>
                    </div>
                    <div className="skill-item p-3 rounded-lg bg-cyan-900/20 border border-cyan-500/20">
                      <div className="flex items-center gap-2">
                        <Terminal size={18} />
                        <span>AI Systems</span>
                      </div>
                    </div>
                    <div className="skill-item p-3 rounded-lg bg-cyan-900/20 border border-cyan-500/20">
                      <div className="flex items-center gap-2">
                        <Cpu size={18} />
                        <span>IOT</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Software Projects */}
        <section
          id="software"
          className="min-h-screen flex flex-col items-center justify-center px-4 py-20"
        >
          <div className="max-w-6xl w-full">
            <div className="glitch-container mb-12">
              <h2
                className="text-4xl md:text-5xl font-bold glitch-text"
                data-text="SOFTWARE MATRIX"
              >
                SOFTWARE MATRIX
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {softwareProjects.map((project) => (
                <HolographicCard key={project.id} project={project} />
              ))}
            </div>
          </div>
        </section>

        {/* Hardware Projects */}
        <section
          id="hardware"
          className="min-h-screen flex flex-col items-center justify-center px-4 py-20"
        >
          <div className="max-w-6xl w-full">
            <div className="glitch-container mb-12">
              <h2
                className="text-4xl md:text-5xl font-bold glitch-text"
                data-text="HARDWARE NEXUS"
              >
                HARDWARE NEXUS
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {hardwareProjects.map((project) => (
                <HolographicCard key={project.id} project={project} />
              ))}
            </div>
          </div>
        </section>

        {/* Contact section */}
        <section
          id="contact"
          className="min-h-screen flex flex-col items-center justify-center px-4 py-20"
        >
          <div className="max-w-4xl w-full">
            <div className="glitch-container mb-12">
              <h2
                className="text-4xl md:text-5xl font-bold glitch-text"
                data-text="NEURAL LINK"
              >
                NEURAL LINK
              </h2>
            </div>

            <div className="holographic-card p-8 rounded-lg backdrop-blur-md bg-opacity-10 bg-blue-900 border border-cyan-500/30">
              <p className="text-lg mb-8 leading-relaxed text-center">
                Establish a neural connection through one of these quantum
                channels
              </p>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <a
                  href="mailto:amanrajengg@gmail.com"
                  className="contact-link flex flex-col items-center p-6 rounded-lg bg-cyan-900/20 border border-cyan-500/20 hover:bg-cyan-800/30 transition-all"
                >
                  <Mail size={32} className="mb-3" />
                  <span className="text-lg">Quantum Mail</span>
                </a>

                <a
                  href="https://github.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="contact-link flex flex-col items-center p-6 rounded-lg bg-cyan-900/20 border border-cyan-500/20 hover:bg-cyan-800/30 transition-all"
                >
                  <Github size={32} className="mb-3" />
                  <span className="text-lg">Code Repository</span>
                </a>

                <a
                  href="https://linkedin.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="contact-link flex flex-col items-center p-6 rounded-lg bg-cyan-900/20 border border-cyan-500/20 hover:bg-cyan-800/30 transition-all"
                >
                  <Linkedin size={32} className="mb-3" />
                  <span className="text-lg">Neural Network</span>
                </a>
              </div>

              <div className="mt-12 text-center">
                <button
                  onClick={() => setShowChat(true)}
                  className="chat-button px-6 py-3 rounded-full bg-gradient-to-r from-cyan-500 to-blue-500 text-white font-medium hover:from-cyan-600 hover:to-blue-600 transition-all"
                >
                  Initiate AI Communication
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="py-8 px-4 border-t border-cyan-800/30">
          <div className="max-w-6xl mx-auto text-center">
            <p className="text-sm opacity-70">
              © {new Date().getFullYear()} Neural Portfolio System • Designed in
              the Quantum Realm
            </p>
            <p className="text-xs mt-2 opacity-50">
              Powered by Sentient AI Core v3.0.1
            </p>
          </div>
        </footer>
      </div>

      {/* Terminal overlay */}
      {terminalOpen && (
        <div
          ref={terminalRef}
          className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-11/12 max-w-2xl h-96 bg-black bg-opacity-90 rounded-lg border border-cyan-500/50 z-50 overflow-hidden"
        >
          <div className="terminal-header flex items-center justify-between p-2 border-b border-cyan-800/50">
            <div className="flex items-center">
              <Terminal size={16} className="mr-2" />
              <span className="text-sm font-mono">Neural Terminal</span>
            </div>
            <button
              onClick={() => setTerminalOpen(false)}
              className="p-1 hover:bg-cyan-900/30 rounded"
            >
              <X size={16} />
            </button>
          </div>

          <div className="terminal-body p-4 h-[calc(100%-64px)] overflow-y-auto font-mono text-sm">
            {terminalOutput.map((line, index) => (
              <div key={index} className="mb-1">
                {line}
              </div>
            ))}
          </div>

          <form
            onSubmit={handleTerminalSubmit}
            className="terminal-input-line border-t border-cyan-800/50 p-2"
          >
            <input
              ref={terminalInputRef}
              type="text"
              value={terminalInput}
              onChange={(e) => setTerminalInput(e.target.value)}
              className="w-full bg-transparent outline-none font-mono text-sm"
              autoFocus
            />
          </form>
        </div>
      )}

      {/* AI Chatbot */}
      {showChat && (
        <ChatBot onClose={() => setShowChat(false)} visitCount={visitCount} />
      )}
    </div>
  );
}

export default App;
