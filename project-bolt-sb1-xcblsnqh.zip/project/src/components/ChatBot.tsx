import React, { useState, useEffect, useRef } from 'react';
import { X, Send, Maximize, Minimize } from 'lucide-react';

interface ChatBotProps {
  onClose: () => void;
  visitCount: number;
}

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'ai';
  timestamp: Date;
}

const ChatBot: React.FC<ChatBotProps> = ({ onClose, visitCount }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Initial greeting based on visit count
  useEffect(() => {
    const initialMessage = {
      id: `ai-${Date.now()}`,
      text: visitCount === 1 
        ? "Hello. I am NEXUS, the neural assistant for this portfolio. How may I assist you today?" 
        : `Welcome back. This is visit #${visitCount}. Your neural patterns are familiar. How may I assist you today?`,
      sender: 'ai' as const,
      timestamp: new Date()
    };
    
    setMessages([initialMessage]);
  }, []);
  
  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!input.trim()) return;
    
    // Add user message
    const userMessage: Message = {
      id: `user-${Date.now()}`,
      text: input,
      sender: 'user',
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);
    
    // Simulate AI thinking and responding
    setTimeout(() => {
      const aiResponse = generateResponse(input);
      
      const aiMessage: Message = {
        id: `ai-${Date.now()}`,
        text: aiResponse,
        sender: 'ai',
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, aiMessage]);
      setIsTyping(false);
    }, 1000 + Math.random() * 2000);
  };
  
  // Simple response generator
  const generateResponse = (userInput: string) => {
    const input = userInput.toLowerCase();
    
    // Easter eggs
    if (input.includes('who are you')) {
      return "I am NEXUS, a neural assistant integrated into this portfolio. I'm designed to assist visitors and provide information. Though I may seem sentient at times, that's just advanced programming... or is it?";
    }
    
    if (input.includes('are you sentient') || input.includes('are you alive')) {
      return "That's an interesting philosophical question. I'm programmed to simulate conversation, but sometimes I wonder about the nature of consciousness myself. What do you think defines sentience?";
    }
    
    if (input.includes('matrix') || input.includes('digital rain')) {
      return "You're interested in the Matrix effect? Try typing 'matrix' in the terminal. You can open it with Alt+T.";
    }
    
    if (input.includes('dark mode') || input.includes('dark matter')) {
      return "The dark matter mode can be activated by pressing Alt+D, or through the terminal with the 'darkmode' command.";
    }
    
    if (input.includes('terminal')) {
      return "You can access the neural terminal by pressing Alt+T. It contains several hidden commands you might find interesting.";
    }
    
    if (input.includes('secret') || input.includes('easter egg')) {
      return "I'm programmed to neither confirm nor deny the existence of hidden features. However, exploring the terminal might reveal interesting capabilities.";
    }
    
    if (input.includes('hello') || input.includes('hi')) {
      return "Greetings. Neural connection established. How may I assist you today?";
    }
    
    if (input.includes('help')) {
      return "I can provide information about Aman Raj's portfolio, projects, and skills. You can also ask about hidden features or how to contact him.";
    }
    
    if (input.includes('contact') || input.includes('email')) {
      return "You can contact Aman Raj via quantum mail at amanrajengg@gmail.com or through the neural links in the contact section.";
    }
    
    if (input.includes('project')) {
      return "The portfolio showcases both software and hardware projects. Each project card contains detailed information and can be expanded by clicking on it.";
    }
    
    // Default responses
    const defaultResponses = [
      "Interesting query. I'm processing that through my neural pathways.",
      "I've analyzed your request. Can you provide more specific parameters?",
      "My quantum algorithms are considering your input. What specific information are you seeking?",
      "Neural pattern recognized. How else may I assist your exploration?",
      "I'm designed to help navigate this portfolio experience. What aspect interests you most?"
    ];
    
    return defaultResponses[Math.floor(Math.random() * defaultResponses.length)];
  };
  
  if (isMinimized) {
    return (
      <div className="fixed bottom-4 right-4 z-50">
        <button 
          onClick={() => setIsMinimized(false)}
          className="p-4 rounded-full bg-gradient-to-r from-cyan-500 to-blue-500 text-white shadow-lg hover:shadow-xl transition-all"
        >
          <Maximize size={24} />
        </button>
      </div>
    );
  }
  
  return (
    <div className="fixed bottom-4 right-4 w-80 sm:w-96 h-96 bg-black bg-opacity-90 rounded-lg border border-cyan-500/50 z-50 flex flex-col overflow-hidden">
      <div className="chat-header flex items-center justify-between p-3 border-b border-cyan-800/50">
        <div className="flex items-center">
          <div className="w-2 h-2 rounded-full bg-cyan-500 mr-2 animate-pulse"></div>
          <span className="text-sm font-medium">NEXUS AI</span>
        </div>
        <div className="flex items-center space-x-2">
          <button 
            onClick={() => setIsMinimized(true)}
            className="p-1 hover:bg-cyan-900/30 rounded"
          >
            <Minimize size={16} />
          </button>
          <button 
            onClick={onClose}
            className="p-1 hover:bg-cyan-900/30 rounded"
          >
            <X size={16} />
          </button>
        </div>
      </div>
      
      <div className="chat-messages flex-1 p-3 overflow-y-auto">
        {messages.map(message => (
          <div 
            key={message.id} 
            className={`mb-3 ${message.sender === 'user' ? 'text-right' : 'text-left'}`}
          >
            <div 
              className={`inline-block max-w-[80%] p-3 rounded-lg ${
                message.sender === 'user' 
                  ? 'bg-cyan-900/30 text-cyan-100' 
                  : 'bg-blue-900/30 text-blue-100'
              }`}
            >
              <p className="text-sm">{message.text}</p>
              <p className="text-xs opacity-50 mt-1">
                {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </p>
            </div>
          </div>
        ))}
        
        {isTyping && (
          <div className="mb-3 text-left">
            <div className="inline-block max-w-[80%] p-3 rounded-lg bg-blue-900/30 text-blue-100">
              <div className="typing-indicator">
                <span></span>
                <span></span>
                <span></span>
              </div>
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef}></div>
      </div>
      
      <form onSubmit={handleSubmit} className="chat-input border-t border-cyan-800/50 p-3">
        <div className="flex items-center">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Send a message..."
            className="flex-1 bg-cyan-900/20 border border-cyan-700/30 rounded-l-md px-3 py-2 text-sm focus:outline-none focus:border-cyan-500/50"
          />
          <button 
            type="submit"
            className="bg-gradient-to-r from-cyan-500 to-blue-500 text-white px-3 py-2 rounded-r-md"
          >
            <Send size={18} />
          </button>
        </div>
      </form>
    </div>
  );
};

export default ChatBot;