import React, { useState, useRef } from 'react';
import { useMousePosition } from '../hooks/useMousePosition';

interface Project {
  id: number;
  title: string;
  description: string;
  tags: string[];
  image: string;
}

interface HolographicCardProps {
  project: Project;
}

const HolographicCard: React.FC<HolographicCardProps> = ({ project }) => {
  const [isHovered, setIsHovered] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);
  const mousePosition = useMousePosition();
  
  const calculateRotation = () => {
    if (!cardRef.current || !isHovered) return { x: 0, y: 0 };
    
    const card = cardRef.current;
    const rect = card.getBoundingClientRect();
    
    // Calculate mouse position relative to card
    const x = mousePosition.x - rect.left;
    const y = mousePosition.y - rect.top;
    
    // Calculate rotation (max 10 degrees)
    const rotateY = ((x / rect.width) - 0.5) * 20;
    const rotateX = ((y / rect.height) - 0.5) * -20;
    
    return { x: rotateX, y: rotateY };
  };
  
  const rotation = calculateRotation();
  
  const cardStyle = {
    transform: isHovered 
      ? `perspective(1000px) rotateX(${rotation.x}deg) rotateY(${rotation.y}deg) scale3d(1.05, 1.05, 1.05)` 
      : 'perspective(1000px) rotateX(0) rotateY(0) scale3d(1, 1, 1)',
    transition: isHovered ? 'transform 0.1s ease-out' : 'transform 0.5s ease-out'
  };
  
  const handleClick = () => {
    setIsExpanded(!isExpanded);
  };
  
  return (
    <div 
      ref={cardRef}
      className={`holographic-card relative rounded-lg overflow-hidden transition-all duration-500 ${
        isExpanded ? 'fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-11/12 max-w-2xl h-auto z-50' : 'h-96'
      }`}
      style={cardStyle}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={handleClick}
    >
      {/* Holographic overlay */}
      <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/10 to-blue-500/10 pointer-events-none"></div>
      
      {/* Card content */}
      <div className="absolute inset-0 p-6 backdrop-blur-sm bg-black bg-opacity-50 border border-cyan-500/30 flex flex-col">
        <div className="flex-1">
          <div className="relative h-40 mb-4 overflow-hidden rounded-md">
            <img 
              src={project.image} 
              alt={project.title} 
              className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent"></div>
          </div>
          
          <h3 className="text-xl font-bold mb-2">{project.title}</h3>
          
          <p className="text-sm opacity-80 mb-4">
            {project.description}
          </p>
          
          <div className="flex flex-wrap gap-2">
            {project.tags.map((tag, index) => (
              <span 
                key={index} 
                className="text-xs px-2 py-1 rounded-full bg-cyan-900/30 border border-cyan-500/20"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>
        
        {isExpanded && (
          <div className="mt-6 pt-6 border-t border-cyan-800/30">
            <h4 className="text-lg font-semibold mb-3">Project Details</h4>
            <p className="text-sm mb-4">
              This advanced project represents the cutting edge of technological innovation, 
              combining quantum computing principles with neural network architecture to create 
              a system that pushes the boundaries of what's currently possible.
            </p>
            <p className="text-sm mb-4">
              The implementation features a multi-layered approach to problem-solving, 
              utilizing advanced algorithms and cybernetic principles to achieve unprecedented 
              results in the field.
            </p>
            <div className="text-center mt-6">
              <button className="px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-md text-white">
                View Full Project
              </button>
            </div>
          </div>
        )}
      </div>
      
      {/* Holographic edge glow */}
      <div className="absolute inset-0 pointer-events-none border border-cyan-400/30 rounded-lg"></div>
      <div className="absolute inset-0 pointer-events-none holographic-glow"></div>
    </div>
  );
};

export default HolographicCard;