import React, { useState, useEffect } from 'react';

interface BootSequenceProps {
  onComplete: () => void;
}

const BootSequence: React.FC<BootSequenceProps> = ({ onComplete }) => {
  const [progress, setProgress] = useState(0);
  const [currentLog, setCurrentLog] = useState('');
  const [logs, setLogs] = useState<string[]>([]);
  const [showPortfolio, setShowPortfolio] = useState(false);

  const bootLogs = [
    'Initializing Neural Interface...',
    'Decoding Quantum Data Streams...',
    'Stabilizing Holographic Projection...',
    'Calibrating Dimensional Anchors...',
    'Synchronizing Temporal Matrices...',
    'Activating Sentient Core...',
    'Establishing Reality Parameters...',
    'Loading Cybernetic Framework...',
    'Quantum Verification Complete...',
    'Neural Portfolio System Online.'
  ];

  useEffect(() => {
    let currentIndex = 0;
    let currentLogTimer: NodeJS.Timeout;
    let progressTimer: NodeJS.Timeout;

    // Display boot logs sequentially
    const displayNextLog = () => {
      if (currentIndex < bootLogs.length) {
        const log = bootLogs[currentIndex];
        setCurrentLog(log);
        
        // Simulate typing effect for each log
        let charIndex = 0;
        const typeLog = () => {
          if (charIndex <= log.length) {
            setCurrentLog(log.substring(0, charIndex));
            charIndex++;
            currentLogTimer = setTimeout(typeLog, 30);
          } else {
            // Log complete, add to logs array
            setLogs(prev => [...prev, log]);
            currentIndex++;
            
            // Small delay before next log
            setTimeout(displayNextLog, 300);
          }
        };
        
        typeLog();
      } else {
        // All logs displayed, show PORTFOLIO text
        setShowPortfolio(true);
        
        // Complete boot sequence after animation
        setTimeout(onComplete, 2000);
      }
    };

    // Start progress bar
    progressTimer = setInterval(() => {
      setProgress(prev => {
        const newProgress = prev + (1 + Math.random() * 2);
        return newProgress > 100 ? 100 : newProgress;
      });
    }, 100);

    // Start displaying logs
    displayNextLog();

    return () => {
      clearTimeout(currentLogTimer);
      clearInterval(progressTimer);
    };
  }, []);

  return (
    <div className="fixed inset-0 bg-black text-cyan-400 font-mono flex flex-col items-center justify-center z-50">
      {!showPortfolio ? (
        <div className="w-full max-w-md p-4">
          <div className="mb-8">
            <div className="text-xs opacity-70 mb-1">Neural Portfolio System v3.0.1</div>
            <div className="h-1 w-full bg-cyan-900 rounded-full overflow-hidden">
              <div 
                className="h-full bg-cyan-500 transition-all duration-300"
                style={{ width: `${progress}%` }}
              ></div>
            </div>
            <div className="text-xs mt-1 flex justify-between">
              <span>Initializing...</span>
              <span>{Math.round(progress)}%</span>
            </div>
          </div>
          
          <div className="boot-logs h-64 overflow-hidden">
            {logs.map((log, index) => (
              <div key={index} className="log-line mb-2 text-sm">
                <span className="text-cyan-600 mr-2">[SYS]</span>
                <span className={`${index === logs.length - 1 ? 'text-cyan-300' : 'text-cyan-500'}`}>
                  {log}
                </span>
              </div>
            ))}
            
            {currentLog && (
              <div className="log-line mb-2 text-sm">
                <span className="text-cyan-600 mr-2">[SYS]</span>
                <span className="text-cyan-300">{currentLog}</span>
                <span className="cursor-blink">_</span>
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="glitch-container">
          <h1 
            className="text-6xl md:text-8xl font-bold glitch-text" 
            data-text="PORTFOLIO"
          >
            PORTFOLIO
          </h1>
        </div>
      )}
    </div>
  );
};

export default BootSequence;