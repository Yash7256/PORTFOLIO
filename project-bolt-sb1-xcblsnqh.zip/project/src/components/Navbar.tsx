import React, { useState, useEffect } from 'react';
import { Menu, X, Moon, Sun, Terminal } from 'lucide-react';

interface NavbarProps {
  darkMode: boolean;
  toggleDarkMode: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ darkMode, toggleDarkMode }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };

    const timeInterval = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    window.addEventListener('scroll', handleScroll);
    
    return () => {
      window.removeEventListener('scroll', handleScroll);
      clearInterval(timeInterval);
    };
  }, []);

  const formatTime = () => {
    return currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  };

  return (
    <nav 
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        scrolled ? 'bg-black bg-opacity-70 backdrop-blur-md py-2' : 'bg-transparent py-4'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <span className="text-xl font-bold tracking-wider glitch-text-small" data-text="NEURAL.SYS">
                NEURAL.SYS
              </span>
            </div>
            
            <div className="hidden md:block ml-10">
              <div className="flex items-baseline space-x-8">
                <a href="#about" className="nav-link">NEURAL IDENTITY</a>
                <a href="#software" className="nav-link">SOFTWARE MATRIX</a>
                <a href="#hardware" className="nav-link">HARDWARE NEXUS</a>
                <a href="#contact" className="nav-link">NEURAL LINK</a>
              </div>
            </div>
          </div>
          
          <div className="hidden md:flex items-center space-x-4">
            <div className="text-sm font-mono opacity-70">
              <span className="mr-2">SYS.TIME:</span>
              <span>{formatTime()}</span>
            </div>
            
            <button 
              onClick={toggleDarkMode}
              className="p-2 rounded-full hover:bg-cyan-900/30 transition-colors"
              aria-label="Toggle dark mode"
            >
              {darkMode ? <Sun size={20} /> : <Moon size={20} />}
            </button>
            
            <button 
              onClick={() => document.dispatchEvent(new KeyboardEvent('keydown', { key: 't', altKey: true }))}
              className="p-2 rounded-full hover:bg-cyan-900/30 transition-colors"
              aria-label="Open terminal"
            >
              <Terminal size={20} />
            </button>
          </div>
          
          <div className="md:hidden flex items-center space-x-4">
            <button 
              onClick={toggleDarkMode}
              className="p-2 rounded-full hover:bg-cyan-900/30 transition-colors"
              aria-label="Toggle dark mode"
            >
              {darkMode ? <Sun size={20} /> : <Moon size={20} />}
            </button>
            
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="p-2 rounded-full hover:bg-cyan-900/30 transition-colors"
              aria-label="Open menu"
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile menu */}
      {isOpen && (
        <div className="md:hidden">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-black bg-opacity-90 backdrop-blur-md">
            <a 
              href="#about" 
              className="block px-3 py-2 rounded-md text-base font-medium hover:bg-cyan-900/30"
              onClick={() => setIsOpen(false)}
            >
              NEURAL IDENTITY
            </a>
            <a 
              href="#software" 
              className="block px-3 py-2 rounded-md text-base font-medium hover:bg-cyan-900/30"
              onClick={() => setIsOpen(false)}
            >
              SOFTWARE MATRIX
            </a>
            <a 
              href="#hardware" 
              className="block px-3 py-2 rounded-md text-base font-medium hover:bg-cyan-900/30"
              onClick={() => setIsOpen(false)}
            >
              HARDWARE NEXUS
            </a>
            <a 
              href="#contact" 
              className="block px-3 py-2 rounded-md text-base font-medium hover:bg-cyan-900/30"
              onClick={() => setIsOpen(false)}
            >
              NEURAL LINK
            </a>
            <button 
              onClick={() => document.dispatchEvent(new KeyboardEvent('keydown', { key: 't', altKey: true }))}
              className="flex items-center w-full px-3 py-2 rounded-md text-base font-medium hover:bg-cyan-900/30"
            >
              <Terminal size={18} className="mr-2" />
              TERMINAL
            </button>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;