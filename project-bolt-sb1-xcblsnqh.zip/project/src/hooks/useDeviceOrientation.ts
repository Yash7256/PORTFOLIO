import { useState, useEffect } from 'react';

interface DeviceOrientation {
  alpha: number | null; // Z-axis rotation [0, 360)
  beta: number | null;  // X-axis rotation [-180, 180)
  gamma: number | null; // Y-axis rotation [-90, 90)
}

export const useDeviceOrientation = (): DeviceOrientation => {
  const [orientation, setOrientation] = useState<DeviceOrientation>({
    alpha: null,
    beta: null,
    gamma: null
  });
  
  useEffect(() => {
    const handleOrientation = (event: DeviceOrientationEvent) => {
      setOrientation({
        alpha: event.alpha,
        beta: event.beta,
        gamma: event.gamma
      });
    };
    
    // Check if device orientation is supported
    if (window.DeviceOrientationEvent) {
      window.addEventListener('deviceorientation', handleOrientation);
    }
    
    return () => {
      if (window.DeviceOrientationEvent) {
        window.removeEventListener('deviceorientation', handleOrientation);
      }
    };
  }, []);
  
  return orientation;
};